# Qiskit Ignis Examples

This collection of notebooks contains examples for how to use the various components of [Qiskit Ignis](https://github.com/Qiskit/qiskit-ignis). The examples are run on Qiskit Aer, but can easily be ported to any backend.
