---
name: "\U0001F680 Feature request"
about: "Suggest an idea for this project \U0001F4A1!"
title: ''
labels: enhancement
assignees: ''

---

<!-- ⚠️ If you do not respect this template, your issue will be closed -->
<!-- ⚠️ Make sure to browse the opened and closed issues to confirm this idea does not exist. -->

### What is the expected behavior?


