# Tutorial Audio Files

This is the folder for the two audio files associated with the Laurel/Yanny 'hello world' tutorial. One file has been adjusted to make 'Laurel' sound more distinct, and the other to make 'Yanny' sound more distinct.

The audio files are equalized versions of the recording found at https://www.vocabulary.com/dictionary/laurel, used under Fair Use provisions and cited as follows: "Text from Vocabulary.com, Copyright ©1998-2018 Thinkmap, Inc. All rights reserved."
