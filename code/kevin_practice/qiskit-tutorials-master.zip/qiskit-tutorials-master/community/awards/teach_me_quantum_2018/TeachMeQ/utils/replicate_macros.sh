cp macros.sty ../"Week 0 - Hello Quantum World"/latex/
cp macros.sty ../"Week 1 - Quantum Tools"/latex/
cp macros.sty ../"Week 2 - Quantum Information Science"/latex/
cp macros.sty ../"Week 3 - Quantum Gates"/latex/
cp macros.sty ../"Week 4 - Quantum Facts"/latex/
cp macros.sty ../"Week 5 - Quantum Algorithms"/latex/
cp macros.sty ../"Week 6 - Quantum Search"/latex/
cp macros.sty ../"Week 7 - Quantum Factorization"/latex/
cp macros.sty ../"Week 8 - High Level Quantum Programming"/latex/
cp macros.sty ../"Week 9 - State of the Quantum Art"/latex/